#!/system/bin/sh
ACTION=$1
ARG=$2

# FUNGSI SUHU UNIVERSAL
get_temp() {
    # Scan semua sensor, cari yang ada kata 'cpu', 'soc', 'tsens' (Snapdragon), atau 'mtk' (MediaTek)
    for tz in /sys/class/thermal/thermal_zone*; do
        if [ -f "$tz/type" ] && [ -f "$tz/temp" ]; then
            tipe=$(cat "$tz/type" | tr '[:upper:]' '[:lower:]')
            case "$tipe" in
                *cpu*|*soc*|*tsens*|*mtktsc*|*apc*)
                    t=$(cat "$tz/temp" 2>/dev/null)
                    if [ ! -z "$t" ] && [ "$t" -gt 0 ]; then
                        echo "$t"
                        return
                    fi
                    ;;
            esac
        fi
    done
    # Fallback: Kalau gagal, baca sensor baterai
    BATT=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)
    [ ! -z "$BATT" ] && echo $((BATT * 100)) && return
    echo "0"
}

# FUNGSI FREKUENSI UNIVERSAL
get_freq() {
    MAX_F=0
    # Scan semua policy CPU, ambil angka yang paling ngebut (nyala)
    for policy in /sys/devices/system/cpu/cpufreq/policy*; do
        if [ -f "$policy/scaling_cur_freq" ]; then
            f=$(cat "$policy/scaling_cur_freq" 2>/dev/null)
            if [ ! -z "$f" ] && [ "$f" -gt "$MAX_F" ]; then
                MAX_F=$f
            fi
        fi
    done
    echo "$MAX_F"
}

lock_auto() {
    touch /dev/perf_manual_lock
    (sleep 3600 && rm -f /dev/perf_manual_lock) &
}

case $ACTION in
    "info")
        KERNEL=$(uname -r)
        CHIPSET=$(getprop ro.board.platform)
        SDK=$(getprop ro.build.version.sdk)
        PID=$(pgrep -f "perf_ultimatum_sd845/service.sh" | head -n 1)
        [ -z "$PID" ] && PID="Not Running"
        echo "$KERNEL|$CHIPSET|$SDK|$PID"
        ;;
        
    "monitor")
        TEMP=$(get_temp)
        MEM=$(cat /proc/meminfo)
        TOTAL=$(echo "$MEM" | grep MemTotal | awk '{print $2}')
        AVAIL=$(echo "$MEM" | grep MemAvailable | awk '{print $2}')
        FREQ=$(get_freq)
        
        echo "$TEMP|$TOTAL|$AVAIL|$FREQ"
        ;;
        
    "flush")
        sync
        echo 3 > /proc/sys/vm/drop_caches
        am kill-all >/dev/null 2>&1
        echo "OK"
        ;;
        
            "underclock")
        lock_auto
        # TRIK UNIVERSAL: Membaca max freq bawaan HP lalu memotongnya jadi persentase
        for policy in /sys/devices/system/cpu/cpufreq/policy*; do
            [ ! -d "$policy" ] && continue
            
            # Baca batas maksimal bawaan pabrik untuk klaster ini
            MAX_FREQ=$(cat $policy/cpuinfo_max_freq 2>/dev/null)
            [ -z "$MAX_FREQ" ] && continue
            
            # Hitung target berdasarkan pilihan
            if [ "$ARG" = "low" ]; then
                TARGET=$((MAX_FREQ * 45 / 100)) # 45% dari performa
            elif [ "$ARG" = "med" ]; then
                TARGET=$((MAX_FREQ * 70 / 100)) # 70% dari performa
            elif [ "$ARG" = "high" ]; then
                TARGET=$((MAX_FREQ * 85 / 100)) # 85% dari performa
            fi
            
            # Terapkan batas baru. Kernel akan otomatis menyesuaikan ke freq terdekat.
            chmod 644 $policy/scaling_max_freq 2>/dev/null
            echo $TARGET > $policy/scaling_max_freq 2>/dev/null
        done
        echo "OK"
        ;;
        
    "disable_cores")
        lock_auto
        # Mematikan core 4-7 (Biasanya Big Core di 90% HP Android Octa-core)
        for core_ctl in /sys/devices/system/cpu/cpu*/core_ctl/enable; do
            chmod 644 "$core_ctl" 2>/dev/null
            echo 0 > "$core_ctl" 2>/dev/null
        done
        for c in 4 5 6 7; do echo 0 > /sys/devices/system/cpu/cpu$c/online 2>/dev/null; done
        # Kalau gagal dimatikan, paksa turun ke 300MHz
        for c in 4 5 6 7; do echo 300000 > /sys/devices/system/cpu/cpu$c/cpufreq/scaling_max_freq 2>/dev/null; done
        echo "OK"
        ;;

    "reset_all")
        # RESET UNIVERSAL: Kembalikan semua ke setelan pabrik
        for policy in /sys/devices/system/cpu/cpufreq/policy*; do
            [ ! -d "$policy" ] && continue
            MAX_FREQ=$(cat $policy/cpuinfo_max_freq 2>/dev/null)
            [ ! -z "$MAX_FREQ" ] && echo $MAX_FREQ > $policy/scaling_max_freq 2>/dev/null
        done
        
        # Hidupkan kembali semua core
        for core_ctl in /sys/devices/system/cpu/cpu*/core_ctl/enable; do
            [ -f "$core_ctl" ] && echo 1 > "$core_ctl" 2>/dev/null
        done
        for online in /sys/devices/system/cpu/cpu*/online; do
            [ -f "$online" ] && echo 1 > "$online" 2>/dev/null
        done
        
        rm -f /dev/perf_manual_lock
        echo "OK"
        ;;
        
    "res")
        if [ "$ARG" = "720" ]; then
            cmd window size 720x1498
            cmd window density 269
        else
            cmd window size reset
            cmd window density reset
        fi
        echo "OK"
        ;;
esac
