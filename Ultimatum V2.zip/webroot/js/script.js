const MOD_ID = "perf_ultimatum_sd845";
const GAME_LIST_PATH = `/data/media/0/Android/gamelist.txt`;

// 1. FUNGSI PENGAMAN ROOT (ANTI-CRASH PARSER)
const callBackend = async (action, arg = "") => {
    try {
        if (!window.ksu) return { success: false, error: "Jembatan KSU belum siap" };
        const cmd = `sh /data/adb/modules/${MOD_ID}/webroot/backend.sh ${action} ${arg}`;
        let res = await window.ksu.exec(cmd);
        
        let errno = 0, stdout = "", stderr = "";
        
        if (typeof res === 'string') {
            try {
                let p = JSON.parse(res);
                errno = p.errno !== undefined ? p.errno : 0;
                stdout = p.stdout !== undefined ? p.stdout : res;
                stderr = p.stderr || "";
            } catch(e) {
                // Kalau gagal parse JSON, berarti KSU Next ngasih raw string
                stdout = res;
            }
        } else if (res && typeof res === 'object') {
            errno = res.errno !== undefined ? res.errno : 0;
            stdout = res.stdout || "";
            stderr = res.stderr || "";
        }
        
        return { success: errno === 0, data: stdout.trim(), error: stderr };
    } catch (e) {
        return { success: false, error: e.toString() };
    }
};

const addLog = (msg) => {
    const box = document.getElementById('log-box');
    if(!box) return;
    const now = new Date();
    const timeStr = now.toLocaleTimeString('id-ID', { hour12: false }); 
    const line = document.createElement('div');
    line.innerHTML = `<span style="color:#00ffff;">[${timeStr}]</span> <span style="color:#fff;">Process: ${msg}</span>`;
    box.prepend(line); 
};

const showToast = (msg, success = true) => {
    const t = document.getElementById('toast');
    const m = document.getElementById('toast-msg');
    if(!t || !m) return;
    m.innerText = msg;
    t.style.borderColor = success ? "#00ffff" : "#ff4444";
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3000);
    addLog(msg);
};

const loadSystemInfo = async () => {
    const res = await callBackend("info");
    if (res.success && res.data) {
        const parts = res.data.split('|');
        if (parts.length >= 4) {
            document.getElementById('info-kernel').innerText = parts[0];
            document.getElementById('info-chipset').innerText = parts[1];
            document.getElementById('info-sdk').innerText = parts[2];
            document.getElementById('info-pid').innerText = parts[3];
            addLog("System Info Loaded.");
        }
    } else {
        addLog(`Error Info: ${res.error || "Gagal baca sistem"}`);
    }
};

let isMonitoring = false;
const updateMonitor = async () => {
    if(isMonitoring) return;
    isMonitoring = true;
    
    try {
        const res = await callBackend("monitor");
        if (res.success && res.data) {
            const p = res.data.split('|');
            if (p.length >= 4) {
                let t = parseInt(p[0]); 
                let tempC = t > 1000 ? Math.round(t/1000) : (t > 200 ? Math.round(t/10) : t);
                document.getElementById('val-temp').innerText = (tempC > 0 ? tempC : "--") + "°C";
                
                let total = parseInt(p[1]); 
                let avail = parseInt(p[2]);
                if (total > 0) document.getElementById('val-ram').innerText = Math.round(((total - avail) / total) * 100) + "%";
                
                let f = parseInt(p[3]); 
                let freqM = f > 1000 ? Math.round(f / 1000) : f;
                document.getElementById('val-freq').innerText = (freqM > 0 ? freqM : "--") + " MHz";
            }
        }
    } finally {
        isMonitoring = false;
        setTimeout(updateMonitor, 2000);
    }
};

// === LOGIKA SWIPE BARU ===
const swipeContainer = document.getElementById('swipe-container');
const navItems = [document.getElementById('nav-home'), document.getElementById('nav-tuning')];

// Update warna Nav Bar saat layar digeser pakai jari
swipeContainer.addEventListener('scroll', () => {
    let pageIndex = Math.round(swipeContainer.scrollLeft / window.innerWidth);
    navItems.forEach(el => el.classList.remove('active'));
    
    // Ganti icon biar mantap
    navItems[0].querySelector('i').className = pageIndex === 0 ? 'ph-fill ph-house' : 'ph ph-house';
    navItems[1].querySelector('i').className = pageIndex === 1 ? 'ph-fill ph-sliders' : 'ph ph-sliders';
    
    if(navItems[pageIndex]) navItems[pageIndex].classList.add('active');
});

// Bergerak saat ikon di Nav Bar ditekan
window.clickTab = (index) => {
    swipeContainer.scrollTo({
        left: index * window.innerWidth,
        behavior: 'smooth'
    });
};
// ==========================

document.getElementById('btn-perf').onclick = async () => { const res = await callBackend("gov", "performance"); showToast("Performance Mode Aktif! 🚀", res.success); };
document.getElementById('btn-bal').onclick = async () => { const res = await callBackend("gov", "schedutil"); showToast("Balanced Mode Aktif! ⚖️", res.success); };
document.getElementById('btn-power').onclick = async () => { const res = await callBackend("gov", "powersave"); showToast("Powersave Mode Aktif! 🍃", res.success); };
document.getElementById('btn-flush').onclick = async () => { const res = await callBackend("flush"); showToast("Memory Cleared! 🧹", res.success); };

document.getElementById('btn-uc').onclick = async () => { 
    const mode = document.getElementById('uc-freq').value; 
    const res = await callBackend("underclock", mode); 
    showToast(`Underclock Mode ${mode.toUpperCase()} Aktif! 📉`, res.success); 
};
document.getElementById('btn-core').onclick = async () => { const res = await callBackend("disable_cores"); showToast("Big Cores Dimatikan! 🧊", res.success); };
document.getElementById('btn-reset').onclick = async () => { const res = await callBackend("reset_all"); showToast("Semua Tweak Direset! 🔄", res.success); };

document.getElementById('btn-res720').onclick = async () => { const res = await callBackend("res", "720"); showToast("Resolusi 720p Aktif! 📱", res.success); };
document.getElementById('btn-res1080').onclick = async () => { const res = await callBackend("res", "1080"); showToast("Resolusi 1080p Aktif! 📱", res.success); };

document.getElementById('btn-telegram').onclick = () => { window.ksu.exec("am start -a android.intent.action.VIEW -d https://t.me/LieShiHuang"); };

const loadGames = async () => {
    try {
        const res = await window.ksu.exec(`cat ${GAME_LIST_PATH}`);
        let stdout = "";
        if (typeof res === 'string') {
            try { stdout = JSON.parse(res).stdout; } 
            catch(e) { stdout = res; }
        } else if (res && typeof res === 'object') {
            stdout = res.stdout;
        }
        
        const list = document.getElementById('game-list');
        list.innerHTML = '';
        if(stdout) {
            const pkgs = stdout.split('\n').map(p => p.trim()).filter(p => p && !p.startsWith('#'));
            pkgs.forEach(pkg => {
                const li = document.createElement('li');
                li.style.cssText = "display: flex; justify-content: space-between; padding: 10px; background: rgba(0,0,0,0.3); margin-bottom: 5px; border-radius: 5px;";
                li.innerHTML = `<span>${pkg}</span><i class="ph ph-trash" style="color:#ff4444; cursor:pointer;" onclick="removeGame('${pkg}')"></i>`;
                list.appendChild(li);
            });
        }
    } catch(e) {}
};

window.removeGame = async (pkg) => {
    await window.ksu.exec(`sh -c "sed -i '/^${pkg}$/d' ${GAME_LIST_PATH}"`);
    showToast('Game Dihapus! 🗑️');
    loadGames();
};

document.getElementById('btn-addgame').onclick = async () => {
    let pkg = document.getElementById('game-input').value.trim();
    if(pkg) {
        await window.ksu.exec(`sh -c "echo '${pkg}' >> ${GAME_LIST_PATH}"`);
        document.getElementById('game-input').value = '';
        showToast('Game Ditambahkan! 🎮');
        loadGames();
    }
};

// ==========================================
// SISTEM MULTI-BAHASA (LOCALIZATION)
// ==========================================
const dict = {
    'id': {
        'txt-pid': 'Daemon PID:',
        'txt-mon': 'Live Monitor',
        'txt-gov': 'Governor & Tools',
        'txt-bat': 'Battery & Extreme Tweaks',
        'txt-dis': 'Display Rescaler',
        'txt-agl': 'Auto Gaming List',
        'txt-log': 'System Logs',
        'txt-feed': 'Feedback & Saran',
        'opt-low': 'Low (Sangat Hemat)',
        'opt-med': 'Medium (Seimbang)',
        'opt-high': 'High (Ngebut)',
        'btn-perf-txt': 'Performance',
        'btn-bal-txt': 'Balanced',
        'btn-pow-txt': 'Powersave',
        'btn-flush-txt': 'Flush Memory',
        'btn-uc-txt': 'Set Mode',
        'btn-core-txt': 'Matikan Big Cores',
        'btn-reset-txt': 'Reset Default',
        'btn-720-txt': '720p Mode',
        'btn-1080-txt': '1080p Mode',
        'tab-home-txt': 'Beranda',
        'tab-tun-txt': 'Setelan',
        'game-input': 'contoh: com.mobile.legends'
    },
    'en': {
        'txt-pid': 'Daemon PID:',
        'txt-mon': 'Live Monitor',
        'txt-gov': 'Governor & Tools',
        'txt-bat': 'Battery & Extreme Tweaks',
        'txt-dis': 'Display Rescaler',
        'txt-agl': 'Auto Gaming List',
        'txt-log': 'System Logs',
        'txt-feed': 'Feedback & Support',
        'opt-low': 'Low (Super Battery)',
        'opt-med': 'Medium (Balanced)',
        'opt-high': 'High (Performance)',
        'btn-perf-txt': 'Performance',
        'btn-bal-txt': 'Balanced',
        'btn-pow-txt': 'Powersave',
        'btn-flush-txt': 'Flush Memory',
        'btn-uc-txt': 'Set Mode',
        'btn-core-txt': 'Disable Big Cores',
        'btn-reset-txt': 'Reset Default',
        'btn-720-txt': '720p Mode',
        'btn-1080-txt': '1080p Mode',
        'tab-home-txt': 'Home',
        'tab-tun-txt': 'Tuning',
        'game-input': 'e.g., com.mobile.legends'
    }
};

const safeSetLang = (lang) => { try { localStorage.setItem('ulti_lang', lang); } catch(e){} };
const safeGetLang = () => { try { return localStorage.getItem('ulti_lang') || 'id'; } catch(e){ return 'id'; } };

const changeLanguage = (lang) => {
    safeSetLang(lang);
    const t = dict[lang] || dict['id'];
    for (const key in t) {
        const el = document.getElementById(key);
        if (el) {
            if (el.tagName === 'INPUT') el.placeholder = t[key];
            else el.innerText = t[key];
        }
    }
};

document.getElementById('lang-switch').addEventListener('change', (e) => {
    changeLanguage(e.target.value);
});

const startApp = () => {
    let savedLang = safeGetLang();
    document.getElementById('lang-switch').value = savedLang;
    changeLanguage(savedLang);

    setTimeout(() => {
        loadSystemInfo();
        updateMonitor();
        loadGames();
    }, 300);
};

window.addEventListener('DOMContentLoaded', startApp);
